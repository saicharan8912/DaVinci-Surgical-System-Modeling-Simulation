#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64
import math 


def manipulator_control():
    rospy.init_node('manipulator_control') 
    motor_1 = rospy.Publisher('/project_2_final/J1_controller/command', Float64, queue_size=10)
    motor_2 = rospy.Publisher('/project_2_final/J2_controller/command', Float64, queue_size=10)
    motor_3 = rospy.Publisher('/project_2_final/J3_controller/command', Float64, queue_size=10)
    motor_4 = rospy.Publisher('/project_2_final/J4_controller/command', Float64, queue_size=10)
    motor_5 = rospy.Publisher('/project_2_final/J5_controller/command', Float64, queue_size=10)
    motor_6 = rospy.Publisher('/project_2_final/J6_controller/command', Float64, queue_size=10)
    motor_7 = rospy.Publisher('/project_2_final/J7_controller/command', Float64, queue_size=10)
    motor_8 = rospy.Publisher('/project_2_final/J8_controller/command', Float64, queue_size=10)
    rate = rospy.Rate(1) 
    rospy.loginfo("Data is being sent")  
    while not rospy.is_shutdown():
        twist = Float64()
        # initial state
        # twist.data = 2.37
        # motor_1.publish(twist)
        # twist.data = 0
        # motor_2.publish(twist)
        # twist.data = 0
        # motor_3.publish(twist)
        # twist.data = 0
        # motor_4.publish(twist)
        # twist.data = 1.57
        # motor_5.publish(twist)
        # twist.data = 0
        # motor_6.publish(twist)
        # twist.data = 0
        # motor_7.publish(twist)
        # twist.data = 0
        # motor_8.publish(twist)
        # rate.sleep()

        # circle
        # twist.data = 1.57
        # motor_1.publish(twist)
        # twist.data = 1
        # motor_3.publish(twist)
        # twist.data = 2
        # motor_4.publish(twist)
        # twist.data = 3
        # motor_5.publish(twist)
        # twist.data = -1
        # motor_6.publish(twist)
        # twist.data = -0.75
        # motor_7.publish(twist)
        # twist.data = 2
        # motor_8.publish(twist)
        twist.data = 1.57
        motor_1.publish(twist)
        twist.data = 0
        motor_3.publish(twist)
        twist.data = 0
        motor_4.publish(twist)
        twist.data = 0
        motor_5.publish(twist)
        # twist.data = 0
        # twist.data = -0.8
        # twist.data = 0
        
        

        for i in range(0,250):
            twist.data = math.sin(i/25)*1.57
            motor_2.publish(twist)
            motor_7.publish(twist)
            motor_8.publish(twist)
            motor_6.publish(twist)
            rate.sleep()

        # twist.data = -1.57
        # motor_3.publish(twist)
        # rate.sleep()

        # twist.data = 0
        # motor_3.publish(twist)
        # rate.sleep()

        # twist.data = 1.57
        # motor_3.publish(twist)
        # rate.sleep()

        

if __name__ == '__main__':
    try:
        manipulator_control()
    except rospy.ROSInterruptException: 
        pass
